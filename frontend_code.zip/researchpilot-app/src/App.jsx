/**
 * ResearchPilot AI — Full Routed Application
 * ─────────────────────────────────────────────────────────────────────────────
 * Architecture mirrors:
 *   /context/AuthContext
 *   /components/PageWrapper
 *   /components/ProtectedRoute
 *   /pages/Landing, SignIn, SignUp, Dashboard
 *   App (root router)
 *
 * Dependencies: react-router-dom v6, framer-motion
 * ─────────────────────────────────────────────────────────────────────────────
 */

import {
  createContext, useContext, useState, useEffect, useRef, useCallback, useMemo,
} from "react";
import {
  BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate, Link,
} from "react-router-dom";
import {
  motion, useMotionValue, useSpring, useTransform,
  AnimatePresence, LayoutGroup, useAnimation,
} from "framer-motion";

// ─────────────────────────────────────────────────────────────────────────────
// GLOBAL STYLES
// ─────────────────────────────────────────────────────────────────────────────
const GlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@300;400;500&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg: #03020a;
      --bg-mid: #0d1128;
      --indigo: #6366f1;
      --violet: #7c3aed;
      --fuchsia: #a855f7;
      --font-d: 'Syne', sans-serif;
      --font-m: 'DM Mono', monospace;
    }
    html { scroll-behavior: smooth; }
    html, body, #root { height: 100%; }
    body {
      background: var(--bg);
      font-family: var(--font-d);
      color: #e2e0ff;
      overflow-x: hidden;
    }
    ::selection { background: rgba(99,102,241,0.4); }
    ::-webkit-scrollbar { width: 4px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(99,102,241,0.35); border-radius: 2px; }

    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50%       { transform: translateY(-16px); }
    }
    @keyframes breathe {
      0%, 100% { opacity: 0.5; transform: scale(1); }
      50%       { opacity: 0.85; transform: scale(1.07); }
    }
    @keyframes floatUp {
      0%   { transform: translateY(0) translateX(0); opacity: 0; }
      8%   { opacity: 1; }
      92%  { opacity: 0.5; }
      100% { transform: translateY(-110vh) translateX(20px); opacity: 0; }
    }
    @keyframes shimmer {
      0%   { background-position: -300% center; }
      100% { background-position: 300% center; }
    }
    @keyframes rotateSpin {
      to { transform: rotate(360deg); }
    }
    @keyframes scan {
      0%   { transform: translateY(-100%); }
      100% { transform: translateY(400%); }
    }
    @keyframes pulse-ring {
      0%   { transform: scale(1); opacity: 0.7; }
      100% { transform: scale(2.4); opacity: 0; }
    }

    .shimmer-text {
      background: linear-gradient(90deg, #818cf8 0%, #e879f9 30%, #c4b5fd 60%, #818cf8 100%);
      background-size: 200% auto;
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      background-clip: text;
      animation: shimmer 4s linear infinite;
    }
    .shimmer-btn {
      background: linear-gradient(90deg, #6366f1 0%, #7c3aed 30%, #a855f7 50%, #7c3aed 70%, #6366f1 100%);
      background-size: 300% auto;
      animation: shimmer 4s linear infinite;
    }
    .float-1 { animation: float 6s ease-in-out infinite; }
    .float-2 { animation: float 7s ease-in-out infinite 1s; }
    .float-3 { animation: float 8s ease-in-out infinite 0.5s; }
    .float-4 { animation: float 6.5s ease-in-out infinite 2s; }
    .float-5 { animation: float 7.5s ease-in-out infinite 1.5s; }
    .particle { animation: floatUp linear infinite; }

    .glass {
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.07);
      backdrop-filter: blur(20px);
    }
  `}</style>
);

// ─────────────────────────────────────────────────────────────────────────────
// CONTEXT — /context/AuthContext
// ─────────────────────────────────────────────────────────────────────────────
const AuthContext = createContext(null);

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // null = unauthenticated

  const login = useCallback((email) => {
    setUser({ email, name: email.split("@")[0], id: Date.now() });
  }, []);

  const logout = useCallback(() => setUser(null), []);

  const value = useMemo(() => ({ user, login, logout, isAuthenticated: !!user }), [user, login, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

const useAuth = () => useContext(AuthContext);

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE TRANSITION VARIANTS
// ─────────────────────────────────────────────────────────────────────────────

// Determines transition style based on route pairs
const getVariants = (pathname) => {
  if (pathname === "/") {
    // Landing: floats in from below, exits upward (toward auth)
    return {
      initial:  { opacity: 0, y: 40, filter: "blur(12px)", scale: 0.98 },
      animate:  { opacity: 1, y: 0,  filter: "blur(0px)",  scale: 1 },
      exit:     { opacity: 0, y: -60, filter: "blur(14px)", scale: 0.97 },
    };
  }
  if (pathname === "/signin" || pathname === "/signup") {
    // Auth pages: rise from below, exit downward back or upward to dashboard
    return {
      initial:  { opacity: 0, y: 50, filter: "blur(10px)", scale: 0.96 },
      animate:  { opacity: 1, y: 0,  filter: "blur(0px)",  scale: 1 },
      exit:     { opacity: 0, y: -40, filter: "blur(12px)", scale: 0.98 },
    };
  }
  if (pathname === "/dashboard") {
    // Dashboard: elevates upward into view with subtle scale expansion
    return {
      initial:  { opacity: 0, y: 60, filter: "blur(16px)", scale: 0.95 },
      animate:  { opacity: 1, y: 0,  filter: "blur(0px)",  scale: 1 },
      exit:     { opacity: 0, y: 30,  filter: "blur(8px)",  scale: 0.98 },
    };
  }
  return {
    initial:  { opacity: 0, y: 30, filter: "blur(8px)" },
    animate:  { opacity: 1, y: 0,  filter: "blur(0px)" },
    exit:     { opacity: 0, y: -20, filter: "blur(8px)" },
  };
};

const TRANSITION_BASE = {
  duration: 0.72,
  ease: [0.22, 1, 0.36, 1],
};

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENTS — /components/PageWrapper
// ─────────────────────────────────────────────────────────────────────────────

// Route-aware gradient background that shifts per page
const RouteBackground = ({ pathname }) => {
  const gradients = {
    "/":          "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(99,102,241,0.22) 0%, transparent 70%), radial-gradient(ellipse 60% 50% at 80% 80%, rgba(232,121,249,0.12) 0%, transparent 60%)",
    "/signin":    "radial-gradient(ellipse 90% 80% at 50% 50%, rgba(99,102,241,0.16) 0%, rgba(124,58,237,0.06) 40%, transparent 70%)",
    "/signup":    "radial-gradient(ellipse 90% 80% at 50% 50%, rgba(124,58,237,0.14) 0%, rgba(168,85,247,0.06) 40%, transparent 70%)",
    "/dashboard": "radial-gradient(ellipse 70% 50% at 15% 40%, rgba(99,102,241,0.18) 0%, transparent 65%), radial-gradient(ellipse 60% 60% at 85% 70%, rgba(232,121,249,0.1) 0%, transparent 55%)",
  };

  return (
    <motion.div
      key={pathname}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1.2, ease: "easeOut" }}
      style={{
        position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
        background: gradients[pathname] || gradients["/"],
      }}
    />
  );
};

// Full-screen overlay flash during transition
const TransitionOverlay = () => (
  <motion.div
    key="overlay"
    initial={{ opacity: 0 }}
    animate={{ opacity: [0, 0.06, 0] }}
    transition={{ duration: 0.72, ease: "easeInOut" }}
    style={{
      position: "fixed", inset: 0, zIndex: 500, pointerEvents: "none",
      background: "linear-gradient(135deg, rgba(99,102,241,0.15), rgba(168,85,247,0.1))",
    }}
  />
);

const PageWrapper = ({ children }) => {
  const { pathname } = useLocation();
  const variants = getVariants(pathname);

  return (
    <motion.div
      key={pathname}
      variants={variants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={TRANSITION_BASE}
      style={{ position: "relative", zIndex: 10, minHeight: "100vh" }}
    >
      {children}
    </motion.div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENTS — /components/ProtectedRoute
// ─────────────────────────────────────────────────────────────────────────────
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/signin" state={{ from: location }} replace />;
  }
  return children;
};

// ─────────────────────────────────────────────────────────────────────────────
// SHARED UI PRIMITIVES
// ─────────────────────────────────────────────────────────────────────────────

// Shared logo — uses LayoutGroup for morph between pages
const Logo = ({ size = "md", layoutId = "rp-logo" }) => {
  const sizes = { sm: { box: 26, text: "0.85rem" }, md: { box: 32, text: "1rem" }, lg: { box: 42, text: "1.2rem" } };
  const s = sizes[size];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <motion.div
        layoutId={layoutId}
        style={{
          width: s.box, height: s.box, borderRadius: Math.round(s.box * 0.28),
          background: "linear-gradient(135deg, #6366f1, #a855f7)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: s.box * 0.44, fontWeight: 800, color: "#fff",
          flexShrink: 0,
        }}
        animate={{ boxShadow: ["0 0 12px rgba(99,102,241,0.4)", "0 0 28px rgba(99,102,241,0.7)", "0 0 12px rgba(99,102,241,0.4)"] }}
        transition={{ duration: 3.5, repeat: Infinity }}
      >R</motion.div>
      <div>
        <div style={{ fontSize: s.text, fontWeight: 800, letterSpacing: "0.01em", lineHeight: 1.1 }}>ResearchPilot</div>
        <div style={{ fontSize: "0.55rem", color: "rgba(165,180,252,0.6)", letterSpacing: "0.18em", fontFamily: "var(--font-m)" }}>AUTONOMOUS INTELLIGENCE</div>
      </div>
    </div>
  );
};

// Floating ambient particles (lightweight, reused across pages)
const AmbientParticles = ({ count = 20 }) => {
  const particles = useRef(
    Array.from({ length: count }, (_, i) => ({
      id: i, x: Math.random() * 100,
      size: Math.random() * 2.5 + 0.8,
      dur: Math.random() * 16 + 12,
      delay: -(Math.random() * 16),
      color: i % 3 === 0 ? "#6366f1" : i % 3 === 1 ? "#7c3aed" : "#a855f7",
    }))
  ).current;

  return (
    <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 1, overflow: "hidden" }}>
      {particles.map(p => (
        <div key={p.id} className="particle" style={{
          position: "absolute", bottom: -8, left: `${p.x}%`,
          width: p.size, height: p.size, borderRadius: "50%",
          background: p.color, filter: `blur(${p.size * 0.5}px)`,
          animationDuration: `${p.dur}s`, animationDelay: `${p.delay}s`, opacity: 0,
        }} />
      ))}
    </div>
  );
};

// Form input with float label
const FormInput = ({ type = "text", placeholder, icon, value, onChange, error, valid, delay = 0, rightSlot }) => {
  const [focused, setFocused] = useState(false);
  const hasVal = value.length > 0;
  const isFloat = focused || hasVal;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      style={{ position: "relative", marginBottom: 4 }}
    >
      <div style={{
        position: "relative", borderRadius: 10,
        transition: "box-shadow 0.3s ease",
        boxShadow: focused
          ? "0 0 0 1px rgba(99,102,241,0.65), 0 0 18px rgba(99,102,241,0.18)"
          : error
          ? "0 0 0 1px rgba(239,68,68,0.5), 0 0 12px rgba(239,68,68,0.12)"
          : valid
          ? "0 0 0 1px rgba(16,185,129,0.4)"
          : "0 0 0 1px rgba(255,255,255,0.08)",
      }}>
        <motion.label
          animate={{
            y: isFloat ? -9 : 0,
            fontSize: isFloat ? "0.6rem" : "0.82rem",
            color: focused ? "rgba(99,102,241,0.95)" : "rgba(255,255,255,0.32)",
          }}
          transition={{ duration: 0.22 }}
          style={{
            position: "absolute", left: 44,
            top: isFloat ? 8 : "50%",
            transform: isFloat ? "none" : "translateY(-50%)",
            pointerEvents: "none", zIndex: 2,
            letterSpacing: "0.04em", fontFamily: "var(--font-m)",
          }}
        >{placeholder}</motion.label>

        <div style={{
          position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)",
          fontSize: 14, opacity: focused ? 0.9 : 0.35,
          transition: "opacity 0.25s", zIndex: 2,
        }}>{icon}</div>

        <input
          type={type} value={value}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: "100%", background: "rgba(255,255,255,0.04)",
            border: "none", outline: "none", borderRadius: 10,
            padding: hasVal ? "22px 44px 8px 44px" : "16px 44px",
            color: "#e8e6ff", fontSize: "0.88rem",
            fontFamily: "var(--font-m)", transition: "background 0.25s",
          }}
        />

        <motion.div
          animate={{ scaleX: focused ? 1 : 0 }}
          transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
          style={{
            position: "absolute", bottom: 0, left: "50%",
            transform: "translateX(-50%)", width: "88%", height: 1,
            background: "linear-gradient(90deg, transparent, #6366f1, #a855f7, transparent)",
            borderRadius: 1, transformOrigin: "center",
          }}
        />

        {rightSlot && (
          <div style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", zIndex: 3 }}>
            {rightSlot}
          </div>
        )}

        <AnimatePresence>
          {valid && !rightSlot && (
            <motion.div
              initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
              style={{
                position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)",
                width: 18, height: 18, borderRadius: "50%",
                background: "rgba(16,185,129,0.14)", border: "1px solid rgba(16,185,129,0.5)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 9, color: "#10b981",
              }}
            >✓</motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {error && (
          <motion.p
            initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
            style={{ fontSize: "0.63rem", color: "#f87171", marginTop: 5, marginLeft: 4, fontFamily: "var(--font-m)" }}
          >{error}</motion.p>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// Primary CTA button
const PrimaryBtn = ({ children, onClick, disabled, loading, success, delay = 0, fullWidth = true }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
  >
    <motion.button
      onClick={onClick}
      disabled={disabled || loading || success}
      whileHover={!disabled && !loading ? { scale: 1.025, boxShadow: "0 0 36px rgba(99,102,241,0.55)" } : {}}
      whileTap={!disabled && !loading ? { scale: 0.97 } : {}}
      className={!disabled && !loading ? "shimmer-btn" : ""}
      style={{
        width: fullWidth ? "100%" : "auto",
        padding: "0.9rem 1.8rem", borderRadius: 10,
        border: "none", cursor: disabled ? "not-allowed" : "pointer",
        fontFamily: "var(--font-d)", fontSize: "0.9rem",
        fontWeight: 700, letterSpacing: "0.03em", color: "#fff",
        opacity: disabled ? 0.38 : 1, transition: "opacity 0.3s",
        boxShadow: disabled ? "none" : "0 0 22px rgba(99,102,241,0.3)",
        background: disabled ? "rgba(99,102,241,0.2)" : undefined,
      }}
    >
      <AnimatePresence mode="wait">
        {loading ? (
          <motion.span key="load" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
          >
            <svg width="16" height="16" viewBox="0 0 44 44" style={{ animation: "rotateSpin 0.85s linear infinite" }}>
              <circle cx="22" cy="22" r="19" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="3.5" />
              <circle cx="22" cy="22" r="19" fill="none" stroke="#fff" strokeWidth="3.5"
                strokeDasharray="120" strokeDashoffset="85" strokeLinecap="round" />
            </svg>
            Authenticating...
          </motion.span>
        ) : success ? (
          <motion.span key="ok"
            initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
          ><span>✓</span> Access Granted</motion.span>
        ) : (
          <motion.span key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>{children}</motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  </motion.div>
);

// Glass card container
const GlassCard = ({ children, mouseX, mouseY, maxWidth = 440 }) => {
  const rx = useTransform(mouseY || useMotionValue(0), v => v * 0.006);
  const ry = useTransform(mouseX || useMotionValue(0), v => v * -0.006);

  return (
    <motion.div style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d", perspective: 1200 }}>
      <motion.div
        animate={{ y: [0, -5, 0] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
        style={{
          width: "100%", maxWidth,
          borderRadius: 22,
          background: "rgba(255,255,255,0.04)",
          backdropFilter: "blur(28px)",
          boxShadow: "0 28px 70px rgba(0,0,0,0.55), 0 0 0 1px rgba(99,102,241,0.18) inset, 0 0 50px rgba(99,102,241,0.08)",
          overflow: "hidden", position: "relative",
        }}
      >
        {/* Gradient border */}
        <div style={{
          position: "absolute", inset: 0, borderRadius: 22, pointerEvents: "none", zIndex: 0, padding: 1,
          background: "linear-gradient(135deg, rgba(99,102,241,0.45), rgba(168,85,247,0.18), rgba(99,102,241,0.08))",
          WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
          WebkitMaskComposite: "xor", maskComposite: "exclude",
        }} />
        {/* Light sheen */}
        <div style={{
          position: "absolute", top: 0, left: "-15%", width: "55%", height: "30%",
          background: "linear-gradient(180deg, rgba(255,255,255,0.04), transparent)",
          borderRadius: "0 0 50% 50%", pointerEvents: "none", zIndex: 1,
        }} />
        <div style={{ position: "relative", zIndex: 2, padding: "2.4rem 2.2rem" }}>
          {children}
        </div>
      </motion.div>
    </motion.div>
  );
};

// Divider
const OrDivider = ({ delay }) => (
  <motion.div
    initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay }}
    style={{ display: "flex", alignItems: "center", gap: 12 }}
  >
    {[{ origin: "left", grad: "linear-gradient(90deg, transparent, rgba(255,255,255,0.1))" },
      { origin: "right", grad: "linear-gradient(90deg, rgba(255,255,255,0.1), transparent)" }].map((side, i) => (
      <motion.div key={i}
        initial={{ scaleX: 0 }} animate={{ scaleX: 1 }}
        transition={{ delay: delay + 0.1, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        style={{ flex: 1, height: 1, background: side.grad, transformOrigin: side.origin }}
      />
    ))}
    <span style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.22)", fontFamily: "var(--font-m)", letterSpacing: "0.12em" }}>OR</span>
  </motion.div>
);

// Google button
const GoogleBtn = ({ delay, label = "Continue with Google" }) => {
  const [hov, setHov] = useState(false);
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
    >
      <motion.button
        onHoverStart={() => setHov(true)} onHoverEnd={() => setHov(false)}
        whileTap={{ scale: 0.97 }}
        style={{
          width: "100%", padding: "0.82rem", borderRadius: 10,
          border: `1px solid ${hov ? "rgba(99,102,241,0.55)" : "rgba(255,255,255,0.09)"}`,
          background: hov ? "rgba(99,102,241,0.07)" : "rgba(255,255,255,0.03)",
          color: "rgba(255,255,255,0.75)", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
          fontFamily: "var(--font-d)", fontSize: "0.85rem", fontWeight: 600,
          transition: "all 0.28s ease",
          boxShadow: hov ? "0 0 18px rgba(99,102,241,0.18)" : "none",
        }}
      >
        <svg width="17" height="17" viewBox="0 0 48 48">
          <path fill="#FFC107" d="M43.6 20H24v8h11.3C33.5 33.7 29.3 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6-6C34.5 5.4 29.5 3 24 3 12.9 3 4 11.9 4 23s8.9 20 20 20c11 0 20-9 20-20 0-1.3-.2-2.7-.4-4z"/>
          <path fill="#FF3D00" d="M6.3 13.7l7 5.1C15 15 19.2 12 24 12c3.1 0 5.9 1.1 8.1 2.9l6-6C34.5 5.4 29.5 3 24 3c-7.6 0-14.2 4-18.1 9.9l.4.8z"/>
          <path fill="#4CAF50" d="M24 44c5.2 0 10-1.8 13.6-4.9l-6.3-5.3C29.3 35.5 26.7 36.5 24 36.5c-5.2 0-9.6-3.3-11.3-8l-7 5.4C9.7 39.8 16.3 44 24 44z"/>
          <path fill="#1976D2" d="M43.6 20H24v8h11.3c-.8 2.4-2.4 4.4-4.3 5.8l6.3 5.3C40.9 36 44 30 44 24c0-1.3-.2-2.7-.4-4z"/>
        </svg>
        {label}
      </motion.button>
    </motion.div>
  );
};

// Animated checkbox
const AnimCheckbox = ({ checked, onChange, label }) => (
  <label style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer" }}>
    <motion.div onClick={onChange} whileTap={{ scale: 0.82 }}
      style={{
        width: 17, height: 17, borderRadius: 5, flexShrink: 0,
        border: `1.5px solid ${checked ? "#6366f1" : "rgba(255,255,255,0.18)"}`,
        background: checked ? "rgba(99,102,241,0.22)" : "transparent",
        display: "flex", alignItems: "center", justifyContent: "center",
        transition: "all 0.22s", cursor: "pointer",
        boxShadow: checked ? "0 0 10px rgba(99,102,241,0.35)" : "none",
      }}
    >
      <AnimatePresence>
        {checked && (
          <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
            style={{ fontSize: 9, color: "#a5b4fc", fontWeight: 700 }}
          >✓</motion.span>
        )}
      </AnimatePresence>
    </motion.div>
    <span style={{ fontSize: "0.73rem", color: "rgba(255,255,255,0.38)", fontFamily: "var(--font-m)", userSelect: "none" }}>{label}</span>
  </label>
);

// ─────────────────────────────────────────────────────────────────────────────
// PAGE — /pages/Landing
// ─────────────────────────────────────────────────────────────────────────────
const AGENTS = [
  { id: "planner",    label: "Planner",    icon: "⬡", color: "#6366f1", desc: "Decomposes query into research tasks" },
  { id: "search",     label: "Search",     icon: "◈", color: "#8b5cf6", desc: "Retrieves & self-corrects across sources" },
  { id: "analysis",   label: "Analysis",   icon: "◎", color: "#a78bfa", desc: "Extracts insights from each paper" },
  { id: "synthesis",  label: "Synthesis",  icon: "⬢", color: "#c4b5fd", desc: "Cross-paper reasoning & contradiction detect" },
  { id: "hypothesis", label: "Hypothesis", icon: "✦", color: "#e879f9", desc: "Generates 3 novel research hypotheses" },
];

const FEATURES = [
  { label: "Multi-agent orchestration",       rp: true, others: false },
  { label: "Autonomous hypothesis generation", rp: true, others: false },
  { label: "Cross-paper contradiction detect", rp: true, others: false },
  { label: "Live SSE agent streaming",         rp: true, others: false },
  { label: "Research gap mapping",             rp: true, others: false },
  { label: "Single query → full brief",        rp: true, others: "partial" },
];

const SIM_STEPS = [
  { agent: "Planner",    color: "#6366f1", icon: "⬡", text: "Query decomposed → 6 parallel research tasks",          prog: 100, dur: 700  },
  { agent: "Search",     color: "#8b5cf6", icon: "◈", text: "Self-corrected: 'neural plasticity' → 23 papers found",  prog: 100, dur: 1500 },
  { agent: "Analysis",   color: "#a78bfa", icon: "◎", text: "Analyzing Paper 3 of 8... extracting key claims",        prog: 64,  dur: 2600 },
  { agent: "Synthesis",  color: "#c4b5fd", icon: "⬢", text: "⚠ Contradiction detected: Zhang 2021 vs Lee 2023",       prog: 38,  dur: 3300 },
  { agent: "Hypothesis", color: "#e879f9", icon: "✦", text: "Awaiting synthesis stream...",                           prog: 0,   dur: 4800 },
];

const LandingPage = () => {
  const navigate = useNavigate();
  const mx = useMotionValue(0), my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 55, damping: 20 });
  const sy = useSpring(my, { stiffness: 55, damping: 20 });
  const px1 = useTransform(sx, v => v * 0.35);
  const py1 = useTransform(sy, v => v * 0.35);
  const px2 = useTransform(sx, v => v * -0.28);
  const py2 = useTransform(sy, v => v * -0.28);

  const [simSteps, setSimSteps] = useState(SIM_STEPS.map(s => ({ ...s, status: "pending", progress: 0 })));
  const [simActive, setSimActive] = useState(false);
  const [streamText, setStreamText] = useState("");

  useEffect(() => {
    const h = (e) => { mx.set((e.clientX / window.innerWidth - 0.5) * 38); my.set((e.clientY / window.innerHeight - 0.5) * 38); };
    window.addEventListener("mousemove", h);
    return () => window.removeEventListener("mousemove", h);
  }, []);

  const runSim = () => {
    setSimActive(true); setStreamText("");
    setSimSteps(SIM_STEPS.map(s => ({ ...s, status: "pending", progress: 0 })));
    SIM_STEPS.forEach((step, i) => {
      setTimeout(() => {
        setSimSteps(prev => prev.map((s, j) => {
          if (j < i) return { ...SIM_STEPS[j], status: "complete", progress: 100 };
          if (j === i) return { ...step, status: "running", progress: 0 };
          return s;
        }));
        let p = 0;
        const iv = setInterval(() => {
          p = Math.min(p + Math.random() * 11 + 3, step.prog);
          if (p >= step.prog) { clearInterval(iv); }
          setSimSteps(prev => prev.map((s, j) => j === i ? { ...s, progress: p } : s));
        }, 60);
        if (i === SIM_STEPS.length - 1) {
          const hyps = ["Hypothesis 1: Cortical remapping follows oscillatory interference patterns...", "\nHypothesis 2: Conflicting data reflects age variance (±12yr) across cohorts...", "\nHypothesis 3: Sleep-dependent consolidation mediates DG synaptic downscaling..."];
          let full = "";
          hyps.forEach((h, hi) => setTimeout(() => { let ci = 0; const ci_iv = setInterval(() => { full += h[ci++]; setStreamText(full); if (ci >= h.length) clearInterval(ci_iv); }, 16); }, hi * 700));
        }
      }, step.dur);
    });
  };

  const CARD_POS = [
    { top: "16%", left: "6%", float: "float-1" },
    { top: "62%", left: "4%", float: "float-2" },
    { top: "18%", right: "8%", float: "float-3" },
    { top: "66%", right: "5%", float: "float-4" },
    { top: "40%", right: "1.5%", float: "float-5" },
  ];

  return (
    <div style={{ minHeight: "100vh", overflowX: "hidden" }}>
      {/* NAV */}
      <motion.nav
        initial={{ opacity: 0, y: -22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        style={{
          position: "fixed", top: 0, left: 0, right: 0, zIndex: 200,
          padding: "1.2rem 2.5rem",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          background: "rgba(3,2,10,0.72)", borderBottom: "1px solid rgba(255,255,255,0.05)",
          backdropFilter: "blur(22px)",
        }}
      >
        <Logo size="sm" layoutId="rp-logo" />
        <div style={{ display: "flex", gap: "2rem", fontSize: "0.83rem", color: "rgba(255,255,255,0.45)" }}>
          {["Agents", "Features", "Compare"].map(l => (
            <span key={l} style={{ cursor: "pointer", transition: "color 0.2s" }}
              onMouseEnter={e => e.currentTarget.style.color = "#c4b5fd"}
              onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.45)"}
            >{l}</span>
          ))}
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
            onClick={() => navigate("/signin")}
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)", padding: "0.48rem 1.1rem", borderRadius: 8, fontSize: "0.83rem", fontWeight: 600, cursor: "pointer", fontFamily: "var(--font-d)" }}
          >Sign In</motion.button>
          <motion.button whileHover={{ scale: 1.03, boxShadow: "0 0 22px rgba(99,102,241,0.5)" }} whileTap={{ scale: 0.97 }}
            onClick={() => navigate("/signup")}
            style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", color: "#fff", padding: "0.48rem 1.2rem", borderRadius: 8, fontSize: "0.83rem", fontWeight: 600, cursor: "pointer", boxShadow: "0 0 16px rgba(99,102,241,0.3)", fontFamily: "var(--font-d)" }}
          >Get Access</motion.button>
        </div>
      </motion.nav>

      {/* HERO */}
      <section style={{ minHeight: "100vh", position: "relative", overflow: "hidden", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "8rem 2rem 4rem" }}>
        <div style={{ position: "absolute", inset: 0, opacity: 0.07, backgroundImage: "linear-gradient(rgba(99,102,241,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.5) 1px, transparent 1px)", backgroundSize: "60px 60px", maskImage: "radial-gradient(ellipse 70% 70% at 50% 50%, black 20%, transparent 80%)" }} />

        {AGENTS.map((agent, i) => (
          <motion.div key={agent.id} className={CARD_POS[i].float}
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 + i * 0.12, duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
            style={{ position: "absolute", ...CARD_POS[i], width: 158, zIndex: 2 }}
          >
            <motion.div style={{ x: i % 2 === 0 ? px1 : px2, y: i % 2 === 0 ? py1 : py2 }}>
              <div style={{ padding: "1rem", borderRadius: 14, border: `1px solid ${agent.color}35`, background: `${agent.color}06`, backdropFilter: "blur(16px)", boxShadow: `0 0 24px ${agent.color}15` }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <span style={{ fontSize: 17, color: agent.color }}>{agent.icon}</span>
                  <span style={{ fontSize: "0.7rem", fontWeight: 700, color: agent.color, letterSpacing: "0.08em" }}>{agent.label.toUpperCase()}</span>
                </div>
                <p style={{ fontSize: "0.66rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.45, fontFamily: "var(--font-m)" }}>{agent.desc}</p>
                <div style={{ marginTop: 8, height: 2.5, borderRadius: 2, background: `linear-gradient(90deg, ${agent.color}, transparent)`, width: `${38 + i * 11}%` }} />
              </div>
            </motion.div>
          </motion.div>
        ))}

        {/* Hero text */}
        <div style={{ position: "relative", zIndex: 3, textAlign: "center", maxWidth: 760 }}>
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }}
            style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.28)", borderRadius: 20, padding: "0.33rem 1rem", marginBottom: "1.8rem", fontSize: "0.72rem", color: "#a5b4fc", letterSpacing: "0.1em" }}
          >
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#6366f1", boxShadow: "0 0 8px #6366f1", animation: "pulse-ring 1.6s ease-out infinite" }} />
            5-AGENT AUTONOMOUS RESEARCH SYSTEM
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 28 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.32, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            style={{ fontSize: "clamp(2.8rem, 5.8vw, 5.2rem)", fontWeight: 800, lineHeight: 1.06, marginBottom: "1.4rem", letterSpacing: "-0.03em" }}
          >
            Turn Every Research Question<br />
            <span className="shimmer-text">Into A Breakthrough.</span>
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.6 }}
            style={{ fontSize: "1.1rem", color: "rgba(255,255,255,0.42)", marginBottom: "2.4rem", lineHeight: 1.6, fontFamily: "var(--font-m)", fontWeight: 300 }}
          >Five autonomous AI agents. One question. 90 seconds to insight.</motion.p>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65, duration: 0.6 }}
            style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}
          >
            <motion.button whileHover={{ scale: 1.04, boxShadow: "0 0 38px rgba(99,102,241,0.6)" }} whileTap={{ scale: 0.96 }}
              onClick={() => navigate("/signup")}
              style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", color: "#fff", padding: "0.88rem 2rem", borderRadius: 10, fontSize: "0.95rem", fontWeight: 700, cursor: "pointer", boxShadow: "0 0 28px rgba(99,102,241,0.4)", fontFamily: "var(--font-d)" }}
            >Generate Research Brief →</motion.button>
            <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
              onClick={() => navigate("/signin")}
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.75)", padding: "0.88rem 2rem", borderRadius: 10, fontSize: "0.95rem", fontWeight: 600, cursor: "pointer", fontFamily: "var(--font-d)", backdropFilter: "blur(10px)" }}
            >▷ Sign In</motion.button>
          </motion.div>
        </div>
      </section>

      {/* SIMULATION */}
      <section style={{ padding: "5rem 2rem", maxWidth: 1100, margin: "0 auto" }}>
        <motion.div initial={{ opacity: 0, y: 36 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}
          style={{ textAlign: "center", marginBottom: "3rem" }}
        >
          <p style={{ fontSize: "0.72rem", color: "#8b5cf6", letterSpacing: "0.15em", marginBottom: "0.7rem", fontFamily: "var(--font-m)" }}>LIVE DEMO</p>
          <h2 style={{ fontSize: "clamp(1.9rem, 3.8vw, 3.2rem)", fontWeight: 800, letterSpacing: "-0.02em" }}>
            Watch 5 Agents <span style={{ background: "linear-gradient(135deg,#c4b5fd,#e879f9,#818cf8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>Think Together</span>
          </h2>
        </motion.div>
        <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 18, overflow: "hidden" }}>
          <div style={{ padding: "0.8rem 1.2rem", borderBottom: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", gap: 8, background: "rgba(0,0,0,0.3)" }}>
            {["#ff5f57","#ffbd2e","#28ca42"].map(c => <div key={c} style={{ width: 10, height: 10, borderRadius: "50%", background: c }} />)}
            <span style={{ marginLeft: 8, fontSize: "0.72rem", color: "rgba(255,255,255,0.28)", fontFamily: "var(--font-m)" }}>researchpilot.ai — agent-orchestration</span>
            <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }} onClick={runSim}
              style={{ marginLeft: "auto", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", border: "none", color: "#fff", padding: "0.32rem 0.9rem", borderRadius: 6, fontSize: "0.72rem", fontWeight: 600, cursor: "pointer", fontFamily: "var(--font-d)" }}
            >{simActive ? "▷ Replay" : "▷ Run Demo"}</motion.button>
          </div>
          <div style={{ padding: "1.25rem", display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(185px,1fr))", gap: 10 }}>
            {simSteps.map((step, i) => (
              <motion.div key={step.agent}
                initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.09 }}
                style={{ padding: "1rem", borderRadius: 11, border: `1px solid ${step.status === "running" ? step.color + "40" : "rgba(255,255,255,0.06)"}`, background: step.status === "running" ? `${step.color}07` : "rgba(255,255,255,0.02)", transition: "all 0.35s ease", position: "relative", overflow: "hidden" }}
              >
                {step.status === "running" && <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${step.color}, transparent)`, animation: "scan 2s linear infinite" }} />}
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 16, color: step.color, marginBottom: 3 }}>{step.icon}</div>
                    <div style={{ fontSize: "0.72rem", fontWeight: 700 }}>{step.agent}</div>
                  </div>
                  <span style={{
                    fontSize: "0.58rem", fontWeight: 700, letterSpacing: "0.1em", fontFamily: "var(--font-m)", padding: "2px 7px", borderRadius: 20,
                    color: step.status === "complete" ? "#10b981" : step.status === "running" ? "#f59e0b" : "rgba(255,255,255,0.22)",
                    background: step.status === "complete" ? "rgba(16,185,129,0.1)" : step.status === "running" ? "rgba(245,158,11,0.1)" : "rgba(255,255,255,0.04)",
                    border: `1px solid ${step.status === "complete" ? "rgba(16,185,129,0.4)" : step.status === "running" ? "rgba(245,158,11,0.4)" : "rgba(255,255,255,0.08)"}`,
                  }}>{step.status === "complete" ? "DONE" : step.status === "running" ? "LIVE" : "WAIT"}</span>
                </div>
                <p style={{ fontSize: "0.63rem", color: "rgba(255,255,255,0.38)", marginBottom: 8, lineHeight: 1.4, fontFamily: "var(--font-m)", minHeight: 30 }}>{step.text}</p>
                <div style={{ height: 2.5, borderRadius: 2, background: "rgba(255,255,255,0.05)" }}>
                  <motion.div animate={{ width: `${step.progress}%` }} transition={{ duration: 0.28 }} style={{ height: "100%", borderRadius: 2, background: `linear-gradient(90deg, ${step.color}, ${step.color}99)` }} />
                </div>
              </motion.div>
            ))}
          </div>
          <AnimatePresence>
            {streamText && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                style={{ margin: "0 1.25rem 1.25rem", padding: "1rem 1.2rem", borderRadius: 11, border: "1px solid rgba(232,121,249,0.2)", background: "rgba(232,121,249,0.04)" }}
              >
                <div style={{ fontSize: "0.62rem", color: "#e879f9", letterSpacing: "0.1em", marginBottom: 7, fontFamily: "var(--font-m)" }}>✦ HYPOTHESIS AGENT — STREAMING</div>
                <pre style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.6)", fontFamily: "var(--font-m)", lineHeight: 1.7, whiteSpace: "pre-wrap", margin: 0 }}>{streamText}<span style={{ opacity: 0.6 }}>▌</span></pre>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* COMPARISON */}
      <section style={{ padding: "5rem 2rem", maxWidth: 900, margin: "0 auto" }}>
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}
          style={{ textAlign: "center", marginBottom: "2.5rem" }}
        >
          <p style={{ fontSize: "0.72rem", color: "#a78bfa", letterSpacing: "0.15em", marginBottom: "0.7rem", fontFamily: "var(--font-m)" }}>COMPETITIVE ADVANTAGE</p>
          <h2 style={{ fontSize: "clamp(1.9rem, 3.8vw, 3rem)", fontWeight: 800, letterSpacing: "-0.02em" }}>Not Just <span style={{ color: "rgba(255,255,255,0.22)" }}>Another</span> Research Tool</h2>
        </motion.div>
        <div style={{ border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, overflow: "hidden" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", background: "rgba(0,0,0,0.35)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            {["CAPABILITY", "RESEARCHPILOT AI", "OTHERS"].map((h, i) => (
              <div key={h} style={{ padding: "1rem 1.4rem", fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.08em", fontFamily: "var(--font-m)", textAlign: i > 0 ? "center" : "left", color: i === 1 ? "#a5b4fc" : "rgba(255,255,255,0.28)", background: i === 1 ? "rgba(99,102,241,0.07)" : "transparent", borderLeft: i === 1 ? "1px solid rgba(99,102,241,0.18)" : "none", borderRight: i === 1 ? "1px solid rgba(99,102,241,0.18)" : "none" }}>{h}</div>
            ))}
          </div>
          {FEATURES.map((f, i) => (
            <motion.div key={f.label}
              initial={{ opacity: 0, x: -16 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
              style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", borderBottom: i < FEATURES.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none" }}
            >
              <div style={{ padding: "0.9rem 1.4rem", fontSize: "0.8rem", color: "rgba(255,255,255,0.58)" }}>{f.label}</div>
              <div style={{ padding: "0.9rem 1.4rem", background: "rgba(99,102,241,0.04)", borderLeft: "1px solid rgba(99,102,241,0.13)", borderRight: "1px solid rgba(99,102,241,0.13)", display: "flex", justifyContent: "center", alignItems: "center" }}>
                <motion.span initial={{ scale: 0 }} whileInView={{ scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.28 + i * 0.07, type: "spring", stiffness: 280 }}
                  style={{ width: 20, height: 20, borderRadius: "50%", background: "rgba(16,185,129,0.13)", border: "1px solid rgba(16,185,129,0.45)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.66rem", color: "#10b981" }}
                >✓</motion.span>
              </div>
              <div style={{ padding: "0.9rem 1.4rem", display: "flex", justifyContent: "center", alignItems: "center" }}>
                {f.others === false ? <span style={{ width: 20, height: 20, borderRadius: "50%", background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.28)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.66rem", color: "#ef4444" }}>✕</span>
                  : <span style={{ fontSize: "0.66rem", color: "rgba(245,158,11,0.75)", fontFamily: "var(--font-m)" }}>~PARTIAL</span>}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "7rem 2rem", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse 65% 65% at 50% 50%, rgba(99,102,241,0.15) 0%, transparent 70%)", pointerEvents: "none" }} />
        <div style={{ position: "relative", zIndex: 2, maxWidth: 680, margin: "0 auto" }}>
          <motion.div initial={{ opacity: 0, y: 36 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <h2 style={{ fontSize: "clamp(2.4rem, 4.8vw, 4.2rem)", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "1.2rem", lineHeight: 1.06 }}>
              Your next research<br />breakthrough <span className="shimmer-text">starts now.</span>
            </h2>
            <p style={{ color: "rgba(255,255,255,0.38)", fontSize: "0.98rem", marginBottom: "2.4rem", fontFamily: "var(--font-m)", fontWeight: 300 }}>Type one question. Let five agents do the rest.</p>
            <motion.button whileHover={{ scale: 1.05, boxShadow: "0 0 55px rgba(99,102,241,0.65)" }} whileTap={{ scale: 0.95 }}
              onClick={() => navigate("/signup")}
              style={{ background: "linear-gradient(135deg,#6366f1,#8b5cf6,#e879f9)", border: "none", color: "#fff", padding: "1rem 2.5rem", borderRadius: 12, fontSize: "1.02rem", fontWeight: 700, cursor: "pointer", boxShadow: "0 0 38px rgba(99,102,241,0.45)", fontFamily: "var(--font-d)" }}
            >Generate My Research Brief →</motion.button>
            <p style={{ marginTop: "1.1rem", fontSize: "0.72rem", color: "rgba(255,255,255,0.22)", fontFamily: "var(--font-m)" }}>No credit card required · Results in 90 seconds</p>
          </motion.div>
        </div>
        <div style={{ marginTop: "4.5rem", paddingTop: "1.8rem", borderTop: "1px solid rgba(255,255,255,0.05)", display: "flex", justifyContent: "center", gap: "1.5rem", flexWrap: "wrap", fontSize: "0.68rem", color: "rgba(255,255,255,0.2)", fontFamily: "var(--font-m)" }}>
          <Logo size="sm" layoutId="rp-logo-footer" />
          {["Privacy", "Terms", "Docs", "API"].map(l => <span key={l} style={{ cursor: "pointer" }}>{l}</span>)}
          <span>© 2025 ResearchPilot AI</span>
        </div>
      </section>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// SHARED AUTH LAYOUT (wraps SignIn + SignUp)
// ─────────────────────────────────────────────────────────────────────────────
const AuthLayout = ({ children }) => {
  const rawX = useMotionValue(0), rawY = useMotionValue(0);
  const mouseX = useSpring(rawX, { stiffness: 48, damping: 20 });
  const mouseY = useSpring(rawY, { stiffness: 48, damping: 20 });
  const particles = useRef(Array.from({ length: 24 }, (_, i) => ({ id: i, x: Math.random() * 100, size: Math.random() * 2.8 + 0.8, dur: Math.random() * 16 + 12, delay: -(Math.random() * 16), color: i % 3 === 0 ? "#6366f1" : i % 3 === 1 ? "#7c3aed" : "#a855f7" }))).current;
  const nodes = useRef(Array.from({ length: 9 }, (_, i) => ({ cx: 10 + (i % 3) * 40, cy: 20 + Math.floor(i / 3) * 30 }))).current;

  useEffect(() => {
    const h = (e) => { rawX.set(e.clientX - window.innerWidth / 2); rawY.set(e.clientY - window.innerHeight / 2); };
    window.addEventListener("mousemove", h);
    return () => window.removeEventListener("mousemove", h);
  }, []);

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "2rem", position: "relative" }}>
      {/* Breathing glow */}
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 680, height: 680, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.16) 0%, rgba(124,58,237,0.06) 40%, transparent 70%)", animation: "breathe 8s ease-in-out infinite", pointerEvents: "none" }} />
      {/* Neural lines */}
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.055, pointerEvents: "none" }}>
        <defs><linearGradient id="ng2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#6366f1"/><stop offset="100%" stopColor="#a855f7"/></linearGradient></defs>
        {nodes.map((n1, i) => nodes.slice(i + 1, i + 3).map((n2, j) => (
          <motion.line key={`${i}-${j}`} x1={`${n1.cx}%`} y1={`${n1.cy}%`} x2={`${n2.cx}%`} y2={`${n2.cy}%`}
            stroke="url(#ng2)" strokeWidth="1"
            animate={{ opacity: [0.25, 0.7, 0.25] }} transition={{ duration: 4 + j, repeat: Infinity, delay: i * 0.4 }}
          />
        )))}
      </svg>
      {/* Particles */}
      {particles.map(p => <div key={p.id} className="particle" style={{ position: "absolute", bottom: -8, left: `${p.x}%`, width: p.size, height: p.size, borderRadius: "50%", background: p.color, filter: `blur(${p.size * 0.55}px)`, animationDuration: `${p.dur}s`, animationDelay: `${p.delay}s`, opacity: 0 }} />)}
      {children({ mouseX, mouseY })}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.3 }}
        style={{ marginTop: "1.8rem", display: "flex", gap: "1.4rem", fontSize: "0.6rem", color: "rgba(255,255,255,0.18)", fontFamily: "var(--font-m)", letterSpacing: "0.08em" }}
      >
        {["256-bit TLS", "SOC 2 TYPE II", "GDPR COMPLIANT"].map(t => <span key={t} style={{ display: "flex", alignItems: "center", gap: 5 }}><span style={{ color: "#6366f1", fontSize: 7 }}>▲</span>{t}</span>)}
      </motion.div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// PAGE — /pages/SignIn
// ─────────────────────────────────────────────────────────────────────────────
const SignInPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [remember, setRemember] = useState(false);
  const [emailErr, setEmailErr] = useState("");
  const [pwdErr, setPwdErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [shake, setShake] = useState(false);

  const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isPwdValid = password.length >= 8;
  const canSubmit = isEmailValid && isPwdValid;

  const handleSubmit = useCallback(() => {
    let err = false;
    if (!isEmailValid) { setEmailErr("Enter a valid email address"); err = true; } else setEmailErr("");
    if (!isPwdValid) { setPwdErr("Minimum 8 characters required"); err = true; } else setPwdErr("");
    if (err) { setShake(true); setTimeout(() => setShake(false), 500); return; }
    setLoading(true);
    setTimeout(() => {
      setLoading(false); setSuccess(true);
      setTimeout(() => { login(email); navigate("/dashboard"); }, 900);
    }, 2000);
  }, [isEmailValid, isPwdValid, email, login, navigate]);

  return (
    <AuthLayout>
      {({ mouseX, mouseY }) => (
        <div style={{ width: "100%", maxWidth: 440, position: "relative", zIndex: 10 }}>
          <motion.div initial={{ opacity: 0, y: -18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            style={{ display: "flex", justifyContent: "center", marginBottom: "2rem" }}
          >
            <Link to="/" style={{ textDecoration: "none" }}><Logo size="md" layoutId="rp-logo" /></Link>
          </motion.div>

          <GlassCard mouseX={mouseX} mouseY={mouseY}>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45, duration: 0.55 }}
              style={{ textAlign: "center", marginBottom: "1.9rem" }}
            >
              <h1 style={{ fontSize: "1.55rem", fontWeight: 800, letterSpacing: "-0.02em", background: "linear-gradient(135deg,#e8e6ff,#c4b5fd,#a78bfa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text", marginBottom: "0.38rem" }}>
                Access Intelligence
              </h1>
              <p style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.32)", fontFamily: "var(--font-m)", letterSpacing: "0.03em" }}>
                Enter credentials to initiate the research system
              </p>
            </motion.div>

            <motion.div animate={shake ? { x: [0, -8, 8, -6, 6, -4, 4, 0] } : { x: 0 }} transition={{ duration: 0.44 }}
              style={{ display: "flex", flexDirection: "column", gap: "0.95rem" }}
            >
              <FormInput type="email" placeholder="Email address" icon="◎" value={email}
                onChange={v => { setEmail(v); if (emailErr) setEmailErr(""); }}
                error={emailErr} valid={isEmailValid && email.length > 0} delay={0.58}
              />
              <FormInput
                type={showPwd ? "text" : "password"}
                placeholder="Password" icon={isPwdValid ? "🔓" : "🔒"} value={password}
                onChange={v => { setPassword(v); if (pwdErr) setPwdErr(""); }}
                error={pwdErr} valid={isPwdValid && password.length > 0} delay={0.68}
                rightSlot={
                  <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.72 }}
                    onClick={() => setShowPwd(v => !v)}
                    style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.28)", fontSize: "0.68rem", fontFamily: "var(--font-m)", letterSpacing: "0.05em", padding: "4px", transition: "color 0.2s" }}
                    onMouseEnter={e => e.currentTarget.style.color = "rgba(165,180,252,0.8)"}
                    onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.28)"}
                  >{showPwd ? "HIDE" : "SHOW"}</motion.button>
                }
              />
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.78, duration: 0.45 }}
                style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
              >
                <AnimCheckbox checked={remember} onChange={() => setRemember(v => !v)} label="Keep me signed in" />
                <span style={{ fontSize: "0.7rem", color: "rgba(165,180,252,0.55)", fontFamily: "var(--font-m)", cursor: "pointer", transition: "color 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.color = "#c4b5fd"}
                  onMouseLeave={e => e.currentTarget.style.color = "rgba(165,180,252,0.55)"}
                >Forgot password?</span>
              </motion.div>

              <div style={{ marginTop: "0.35rem" }}>
                <PrimaryBtn onClick={handleSubmit} disabled={!canSubmit && !success} loading={loading} success={success} delay={0.88}>
                  Access ResearchPilot →
                </PrimaryBtn>
              </div>

              <OrDivider delay={0.96} />
              <GoogleBtn delay={1.0} />

              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.06 }}
                style={{ textAlign: "center", fontSize: "0.72rem", color: "rgba(255,255,255,0.28)", fontFamily: "var(--font-m)", marginTop: "0.2rem" }}
              >
                No account?{" "}
                <span onClick={() => navigate("/signup")}
                  style={{ color: "#a78bfa", cursor: "pointer", transition: "color 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.color = "#c4b5fd"}
                  onMouseLeave={e => e.currentTarget.style.color = "#a78bfa"}
                >Request research access →</span>
              </motion.p>
            </motion.div>
          </GlassCard>
        </div>
      )}
    </AuthLayout>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// PAGE — /pages/SignUp
// ─────────────────────────────────────────────────────────────────────────────
const SignUpPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agree, setAgree] = useState(false);
  const [nameErr, setNameErr] = useState("");
  const [emailErr, setEmailErr] = useState("");
  const [pwdErr, setPwdErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [shake, setShake] = useState(false);

  const isNameValid = name.length >= 2;
  const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isPwdValid = password.length >= 8;
  const canSubmit = isNameValid && isEmailValid && isPwdValid && agree;

  const handleSubmit = useCallback(() => {
    let err = false;
    if (!isNameValid) { setNameErr("Full name required"); err = true; } else setNameErr("");
    if (!isEmailValid) { setEmailErr("Enter a valid email address"); err = true; } else setEmailErr("");
    if (!isPwdValid) { setPwdErr("Minimum 8 characters required"); err = true; } else setPwdErr("");
    if (err) { setShake(true); setTimeout(() => setShake(false), 500); return; }
    setLoading(true);
    setTimeout(() => {
      setLoading(false); setSuccess(true);
      setTimeout(() => { login(email); navigate("/dashboard"); }, 900);
    }, 2200);
  }, [isNameValid, isEmailValid, isPwdValid, email, login, navigate]);

  return (
    <AuthLayout>
      {({ mouseX, mouseY }) => (
        <div style={{ width: "100%", maxWidth: 440, position: "relative", zIndex: 10 }}>
          <motion.div initial={{ opacity: 0, y: -18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6 }}
            style={{ display: "flex", justifyContent: "center", marginBottom: "2rem" }}
          >
            <Link to="/" style={{ textDecoration: "none" }}><Logo size="md" layoutId="rp-logo" /></Link>
          </motion.div>

          <GlassCard mouseX={mouseX} mouseY={mouseY}>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45, duration: 0.55 }}
              style={{ textAlign: "center", marginBottom: "1.9rem" }}
            >
              <h1 style={{ fontSize: "1.55rem", fontWeight: 800, letterSpacing: "-0.02em", background: "linear-gradient(135deg,#e8e6ff,#c4b5fd,#e879f9)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text", marginBottom: "0.38rem" }}>
                Join the Research Future
              </h1>
              <p style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.32)", fontFamily: "var(--font-m)", letterSpacing: "0.03em" }}>
                Create your ResearchPilot account
              </p>
            </motion.div>

            <motion.div animate={shake ? { x: [0, -8, 8, -6, 6, -4, 4, 0] } : { x: 0 }} transition={{ duration: 0.44 }}
              style={{ display: "flex", flexDirection: "column", gap: "0.95rem" }}
            >
              <FormInput placeholder="Full name" icon="◇" value={name}
                onChange={v => { setName(v); if (nameErr) setNameErr(""); }}
                error={nameErr} valid={isNameValid && name.length > 0} delay={0.56}
              />
              <FormInput type="email" placeholder="Email address" icon="◎" value={email}
                onChange={v => { setEmail(v); if (emailErr) setEmailErr(""); }}
                error={emailErr} valid={isEmailValid && email.length > 0} delay={0.65}
              />
              <FormInput type="password" placeholder="Password (min 8 chars)" icon="🔒" value={password}
                onChange={v => { setPassword(v); if (pwdErr) setPwdErr(""); }}
                error={pwdErr} valid={isPwdValid && password.length > 0} delay={0.74}
              />

              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.82, duration: 0.45 }}>
                <AnimCheckbox checked={agree} onChange={() => setAgree(v => !v)}
                  label="I agree to Terms of Service and Privacy Policy"
                />
              </motion.div>

              <div style={{ marginTop: "0.3rem" }}>
                <PrimaryBtn onClick={handleSubmit} disabled={!canSubmit && !success} loading={loading} success={success} delay={0.9}>
                  Create Research Account →
                </PrimaryBtn>
              </div>

              <OrDivider delay={0.98} />
              <GoogleBtn delay={1.02} label="Sign up with Google" />

              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.08 }}
                style={{ textAlign: "center", fontSize: "0.72rem", color: "rgba(255,255,255,0.28)", fontFamily: "var(--font-m)", marginTop: "0.2rem" }}
              >
                Already have access?{" "}
                <span onClick={() => navigate("/signin")}
                  style={{ color: "#a78bfa", cursor: "pointer", transition: "color 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.color = "#c4b5fd"}
                  onMouseLeave={e => e.currentTarget.style.color = "#a78bfa"}
                >Sign in →</span>
              </motion.p>
            </motion.div>
          </GlassCard>
        </div>
      )}
    </AuthLayout>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// PAGE — /pages/Dashboard
// ─────────────────────────────────────────────────────────────────────────────
const RECENT_BRIEFS = [
  { id: 1, query: "Neural plasticity mechanisms in adult cortical remapping", agents: 5, papers: 23, time: "1m 28s", status: "complete", date: "2h ago" },
  { id: 2, query: "CRISPR off-target effects in therapeutic gene editing",     agents: 5, papers: 18, time: "1m 12s", status: "complete", date: "5h ago" },
  { id: 3, query: "Quantum error correction thresholds in topological qubits",  agents: 5, papers: 31, time: "1m 45s", status: "complete", date: "1d ago" },
];

const DASH_STATS = [
  { label: "Briefs Generated", value: "47",    icon: "◎", color: "#6366f1" },
  { label: "Papers Analyzed",  value: "1,204", icon: "◈", color: "#8b5cf6" },
  { label: "Hypotheses",       value: "141",   icon: "✦", color: "#e879f9" },
  { label: "Avg. Time",        value: "88s",   icon: "⬢", color: "#a78bfa" },
];

const DashboardPage = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [generating, setGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState("briefs");

  const handleGenerate = () => {
    if (!query.trim()) return;
    setGenerating(true);
    setTimeout(() => setGenerating(false), 3500);
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const stagger = (i) => ({ initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { delay: 0.1 + i * 0.08, duration: 0.55, ease: [0.22, 1, 0.36, 1] } });

  return (
    <div style={{ minHeight: "100vh", overflowX: "hidden" }}>
      {/* Dash Nav */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        style={{ position: "sticky", top: 0, zIndex: 200, padding: "1rem 2.5rem", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(3,2,10,0.8)", borderBottom: "1px solid rgba(255,255,255,0.06)", backdropFilter: "blur(24px)" }}
      >
        <Logo size="sm" layoutId="rp-logo" />
        <div style={{ display: "flex", gap: "0.25rem" }}>
          {["briefs", "agents", "analytics"].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              style={{ padding: "0.42rem 1rem", borderRadius: 8, border: "none", cursor: "pointer", fontFamily: "var(--font-d)", fontSize: "0.8rem", fontWeight: 600, letterSpacing: "0.02em", transition: "all 0.22s", background: activeTab === tab ? "rgba(99,102,241,0.2)" : "transparent", color: activeTab === tab ? "#a5b4fc" : "rgba(255,255,255,0.4)" }}
            >{tab.charAt(0).toUpperCase() + tab.slice(1)}</button>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "0.8rem", fontWeight: 600 }}>{user?.name}</div>
            <div style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.35)", fontFamily: "var(--font-m)" }}>{user?.email}</div>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            style={{ width: 34, height: 34, borderRadius: 10, background: "linear-gradient(135deg,#6366f1,#a855f7)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 800, cursor: "pointer" }}
          >{user?.name?.[0]?.toUpperCase() || "R"}</motion.div>
          <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={handleLogout}
            style={{ padding: "0.42rem 1rem", borderRadius: 8, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.03)", color: "rgba(255,255,255,0.45)", cursor: "pointer", fontSize: "0.78rem", fontFamily: "var(--font-d)", transition: "all 0.22s" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(239,68,68,0.3)"; e.currentTarget.style.color = "#fca5a5"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "rgba(255,255,255,0.45)"; }}
          >Sign out</motion.button>
        </div>
      </motion.nav>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "3rem 2rem" }}>
        {/* Welcome */}
        <motion.div {...stagger(0)} style={{ marginBottom: "2.5rem" }}>
          <div style={{ fontSize: "0.72rem", color: "#8b5cf6", letterSpacing: "0.15em", fontFamily: "var(--font-m)", marginBottom: "0.5rem" }}>RESEARCH INTELLIGENCE DASHBOARD</div>
          <h1 style={{ fontSize: "clamp(1.9rem, 3.5vw, 2.9rem)", fontWeight: 800, letterSpacing: "-0.025em" }}>
            Welcome back, <span style={{ background: "linear-gradient(135deg,#c4b5fd,#e879f9)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>{user?.name}</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.38)", fontSize: "0.92rem", marginTop: "0.4rem", fontFamily: "var(--font-m)", fontWeight: 300 }}>Your autonomous research agents are ready.</p>
        </motion.div>

        {/* Query input */}
        <motion.div {...stagger(1)} style={{ marginBottom: "2.5rem" }}>
          <div style={{
            display: "flex", gap: 10, padding: "0.85rem 1rem",
            background: "rgba(255,255,255,0.03)", borderRadius: 14,
            border: "1px solid rgba(255,255,255,0.08)",
            boxShadow: "0 0 0 1px rgba(99,102,241,0.0)",
            transition: "box-shadow 0.3s",
          }}
            onFocusCapture={e => e.currentTarget.style.boxShadow = "0 0 0 1px rgba(99,102,241,0.4), 0 0 24px rgba(99,102,241,0.1)"}
            onBlurCapture={e => e.currentTarget.style.boxShadow = "0 0 0 1px rgba(255,255,255,0.0)"}
          >
            <span style={{ color: "rgba(99,102,241,0.7)", fontSize: 18, display: "flex", alignItems: "center" }}>◎</span>
            <input value={query} onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleGenerate()}
              placeholder="Ask a research question — e.g., 'What are the mechanisms of CRISPR off-target editing?'"
              style={{ flex: 1, background: "none", border: "none", outline: "none", color: "#e8e6ff", fontSize: "0.9rem", fontFamily: "var(--font-m)", fontWeight: 300 }}
            />
            <motion.button whileHover={{ scale: 1.04, boxShadow: "0 0 22px rgba(99,102,241,0.5)" }} whileTap={{ scale: 0.96 }}
              onClick={handleGenerate} disabled={!query.trim() || generating}
              className={query.trim() && !generating ? "shimmer-btn" : ""}
              style={{ padding: "0.6rem 1.4rem", borderRadius: 9, border: "none", color: "#fff", fontFamily: "var(--font-d)", fontSize: "0.85rem", fontWeight: 700, cursor: query.trim() ? "pointer" : "not-allowed", whiteSpace: "nowrap", opacity: query.trim() ? 1 : 0.35, background: query.trim() && !generating ? undefined : "rgba(99,102,241,0.2)", transition: "opacity 0.25s" }}
            >
              {generating ? (
                <span style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <svg width="13" height="13" viewBox="0 0 44 44" style={{ animation: "rotateSpin 0.8s linear infinite" }}>
                    <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="4"/>
                    <circle cx="22" cy="22" r="18" fill="none" stroke="#fff" strokeWidth="4" strokeDasharray="110" strokeDashoffset="78" strokeLinecap="round"/>
                  </svg>
                  Generating...
                </span>
              ) : "Generate Brief →"}
            </motion.button>
          </div>
          {generating && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
              style={{ marginTop: "1rem", padding: "1rem 1.2rem", background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 11 }}
            >
              <div style={{ display: "flex", gap: "1.5rem", overflowX: "auto", paddingBottom: 4 }}>
                {AGENTS.map((agent, i) => (
                  <motion.div key={agent.id} initial={{ opacity: 0, x: 14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.12 }}
                    style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}
                  >
                    <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ duration: 1.2 + i * 0.2, repeat: Infinity, delay: i * 0.3 }}
                      style={{ width: 8, height: 8, borderRadius: "50%", background: agent.color, boxShadow: `0 0 8px ${agent.color}` }}
                    />
                    <span style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.5)", fontFamily: "var(--font-m)" }}>{agent.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Stats grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12, marginBottom: "2.5rem" }}>
          {DASH_STATS.map((stat, i) => (
            <motion.div key={stat.label} {...stagger(i + 2)}
              whileHover={{ y: -3, boxShadow: `0 12px 30px rgba(0,0,0,0.3), 0 0 0 1px ${stat.color}25` }}
              style={{ padding: "1.4rem", borderRadius: 14, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", transition: "all 0.3s ease", cursor: "default" }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "0.8rem" }}>
                <span style={{ fontSize: 20, color: stat.color }}>{stat.icon}</span>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: `${stat.color}15`, border: `1px solid ${stat.color}25`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: stat.color, animation: "breathe 3s ease-in-out infinite" }} />
                </div>
              </div>
              <div style={{ fontSize: "1.8rem", fontWeight: 800, letterSpacing: "-0.02em", marginBottom: 4 }}>{stat.value}</div>
              <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.38)", fontFamily: "var(--font-m)" }}>{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Recent briefs */}
        <motion.div {...stagger(6)}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.2rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 700, letterSpacing: "0.01em" }}>Recent Research Briefs</h2>
            <span style={{ fontSize: "0.7rem", color: "#8b5cf6", fontFamily: "var(--font-m)", cursor: "pointer" }}>View all →</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {RECENT_BRIEFS.map((brief, i) => (
              <motion.div key={brief.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 + i * 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ x: 4, background: "rgba(99,102,241,0.06)" }}
                style={{ padding: "1.2rem 1.4rem", borderRadius: 12, border: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.02)", transition: "all 0.25s ease", cursor: "pointer" }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "0.88rem", fontWeight: 600, marginBottom: 8, lineHeight: 1.35 }}>{brief.query}</div>
                    <div style={{ display: "flex", gap: "1.2rem", fontSize: "0.65rem", color: "rgba(255,255,255,0.35)", fontFamily: "var(--font-m)" }}>
                      {[`${brief.agents} agents`, `${brief.papers} papers`, `${brief.time}`].map(t => (
                        <span key={t} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                          <span style={{ color: "#6366f1" }}>·</span>{t}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
                    <span style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.3)", fontFamily: "var(--font-m)" }}>{brief.date}</span>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.08em", fontFamily: "var(--font-m)", background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.35)", color: "#10b981" }}>COMPLETE</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// APP — Root router with AnimatePresence
// ─────────────────────────────────────────────────────────────────────────────
const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <>
      <RouteBackground pathname={location.pathname} />
      <AmbientParticles count={18} />

      <AnimatePresence mode="wait" initial={false}>
        {/* Transition overlay flash */}
        <TransitionOverlay key={`overlay-${location.pathname}`} />

        <Routes location={location} key={location.pathname}>
          <Route path="/" element={
            <PageWrapper>
              <LandingPage />
            </PageWrapper>
          } />
          <Route path="/signin" element={
            <PageWrapper>
              <SignInPage />
            </PageWrapper>
          } />
          <Route path="/signup" element={
            <PageWrapper>
              <SignUpPage />
            </PageWrapper>
          } />
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <PageWrapper>
                <DashboardPage />
              </PageWrapper>
            </ProtectedRoute>
          } />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AnimatePresence>
    </>
  );
};

export default function App() {
  return (
    <>
      <GlobalStyles />
      <AuthProvider>
        <BrowserRouter>
          <LayoutGroup>
            <AnimatedRoutes />
          </LayoutGroup>
        </BrowserRouter>
      </AuthProvider>
    </>
  );
}